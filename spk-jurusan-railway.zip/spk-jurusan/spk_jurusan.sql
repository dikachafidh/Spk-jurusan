-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 03 Bulan Mei 2026 pada 10.24
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spk_jurusan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bobot_kriteria`
--

CREATE TABLE `bobot_kriteria` (
  `id` int(11) NOT NULL,
  `jurusan` varchar(10) NOT NULL COMMENT 'Jurusan: DKV / TKR',
  `kriteria` varchar(50) NOT NULL COMMENT 'Nama kriteria',
  `bobot` decimal(3,2) NOT NULL COMMENT 'Bobot kriteria (0-1)',
  `tipe` enum('benefit','cost') DEFAULT 'benefit' COMMENT 'benefit = semakin besar semakin baik, cost = semakin kecil semakin baik',
  `keterangan` text DEFAULT NULL COMMENT 'Keterangan kriteria',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `bobot_kriteria`
--

INSERT INTO `bobot_kriteria` (`id`, `jurusan`, `kriteria`, `bobot`, `tipe`, `keterangan`, `created_at`) VALUES
(1, 'DKV', 'NUS_MTK_SMP', 0.08, 'benefit', 'Matematika cukup penting untuk logika desain', '2026-03-26 14:20:12'),
(2, 'DKV', 'NUS_BIND_SMP', 0.15, 'benefit', 'Bahasa Indonesia penting untuk komunikasi visual', '2026-03-26 14:20:12'),
(3, 'DKV', 'NUS_BING_SMP', 0.12, 'benefit', 'Bahasa Inggris untuk software dan referensi internasional', '2026-03-26 14:20:12'),
(4, 'DKV', 'DISIPLIN', 0.10, 'benefit', 'Kedisiplinan dalam menyelesaikan tugas desain', '2026-03-26 14:20:12'),
(5, 'DKV', 'TANGGUNG_JAWAB', 0.12, 'benefit', 'Tanggung jawab terhadap proyek desain', '2026-03-26 14:20:12'),
(6, 'DKV', 'SIKAP', 0.10, 'benefit', 'Sikap dalam bekerja sama dengan klien', '2026-03-26 14:20:12'),
(7, 'DKV', 'KOMUNIKASI', 0.15, 'benefit', 'Kemampuan komunikasi sangat penting dalam desain', '2026-03-26 14:20:12'),
(8, 'DKV', 'RATA_RATA', 0.10, 'benefit', 'Rata-rata nilai akademik', '2026-03-26 14:20:12'),
(9, 'DKV', 'PENGHASILAN_AYAH', 0.08, 'cost', 'Penghasilan rendah lebih membutuhkan beasiswa untuk DKV', '2026-03-26 14:20:12'),
(10, 'TKR', 'NUS_MTK_SMP', 0.18, 'benefit', 'Matematika sangat penting untuk perhitungan teknik', '2026-03-26 14:20:32'),
(11, 'TKR', 'NUS_BIND_SMP', 0.08, 'benefit', 'Bahasa Indonesia untuk membaca manual', '2026-03-26 14:20:32'),
(12, 'TKR', 'NUS_BING_SMP', 0.08, 'benefit', 'Bahasa Inggris untuk memahami spesifikasi teknis', '2026-03-26 14:20:32'),
(13, 'TKR', 'DISIPLIN', 0.15, 'benefit', 'Disiplin sangat penting dalam pekerjaan teknik', '2026-03-26 14:20:32'),
(14, 'TKR', 'TANGGUNG_JAWAB', 0.15, 'benefit', 'Tanggung jawab terhadap keselamatan kerja', '2026-03-26 14:20:32'),
(15, 'TKR', 'SIKAP', 0.10, 'benefit', 'Sikap dalam bekerja sama di bengkel', '2026-03-26 14:20:32'),
(16, 'TKR', 'KOMUNIKASI', 0.10, 'benefit', 'Komunikasi dengan pelanggan dan rekan kerja', '2026-03-26 14:20:32'),
(17, 'TKR', 'RATA_RATA', 0.08, 'benefit', 'Rata-rata nilai akademik', '2026-03-26 14:20:32'),
(18, 'TKR', 'PENGHASILAN_AYAH', 0.08, 'cost', 'Penghasilan rendah lebih membutuhkan beasiswa untuk TKR', '2026-03-26 14:20:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hasil`
--

CREATE TABLE `hasil` (
  `id` int(11) NOT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `nilai_saw` float DEFAULT NULL,
  `rekomendasi` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat`
--

CREATE TABLE `riwayat` (
  `id` int(11) NOT NULL,
  `waktu` datetime NOT NULL,
  `data` text NOT NULL,
  `total_siswa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `riwayat`
--

INSERT INTO `riwayat` (`id`, `waktu`, `data`, `total_siswa`) VALUES
(1, '2026-05-01 17:34:37', '[{\"nama\":\"Anggoro\",\"skor_dkv\":90.46,\"skor_tkr\":89.15,\"rekomendasi\":\"DKV\",\"kecocokan\":\"Sangat Cocok\",\"skor_beasiswa\":75.49,\"status_beasiswa\":\"Ya\"}]', 1),
(2, '2026-05-01 17:36:05', '[{\"nama\":\"Anggoro\",\"skor_dkv\":90.46,\"skor_tkr\":89.15,\"rekomendasi\":\"DKV\",\"kecocokan\":\"Sangat Cocok\",\"skor_beasiswa\":75.49,\"status_beasiswa\":\"Ya\"},{\"nama\":\"ali\",\"skor_dkv\":69.47,\"skor_tkr\":67.26,\"rekomendasi\":\"DKV\",\"kecocokan\":\"Cukup Cocok\",\"skor_beasiswa\":59.46,\"status_beasiswa\":\"Ya\"}]', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL,
  `nama_siswa` varchar(100) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `pendidikan_ayah` varchar(50) DEFAULT NULL,
  `penghasilan_ayah` varchar(50) DEFAULT NULL,
  `pendidikan_ibu` varchar(50) DEFAULT NULL,
  `transportasi` varchar(50) DEFAULT NULL,
  `nus_mtk_smp` int(11) NOT NULL,
  `nus_bind_smp` int(11) NOT NULL,
  `nus_bing_smp` int(11) NOT NULL,
  `disiplin` int(11) NOT NULL,
  `tanggung_jawab` int(11) NOT NULL,
  `sikap` int(11) NOT NULL,
  `komunikasi` int(11) NOT NULL,
  `rata_rata` decimal(5,2) NOT NULL,
  `standar_deviasi` decimal(5,2) NOT NULL,
  `output_kelas` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `jurusan_asal` varchar(50) DEFAULT NULL COMMENT 'Asal sekolah/jurusan SMP',
  `rekomendasi_jurusan` varchar(10) DEFAULT NULL COMMENT 'Hasil rekomendasi: DKV / TKR',
  `skor_beasiswa` decimal(5,2) DEFAULT NULL,
  `rekomendasi_beasiswa` enum('Ya','Tidak') DEFAULT 'Tidak',
  `skor_dkv` decimal(10,4) DEFAULT NULL COMMENT 'Skor untuk jurusan DKV',
  `skor_tkr` decimal(10,4) DEFAULT NULL COMMENT 'Skor untuk jurusan TKR',
  `tingkat_kecocokan` varchar(20) DEFAULT NULL COMMENT 'Sangat Cocok / Cocok / Cukup / Kurang'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id`, `nama_siswa`, `kelas`, `jenis_kelamin`, `pendidikan_ayah`, `penghasilan_ayah`, `pendidikan_ibu`, `transportasi`, `nus_mtk_smp`, `nus_bind_smp`, `nus_bing_smp`, `disiplin`, `tanggung_jawab`, `sikap`, `komunikasi`, `rata_rata`, `standar_deviasi`, `output_kelas`, `created_at`, `jurusan_asal`, `rekomendasi_jurusan`, `skor_beasiswa`, `rekomendasi_beasiswa`, `skor_dkv`, `skor_tkr`, `tingkat_kecocokan`) VALUES
(1, 'Anggoro', 'IX', 'L', 'SMP/MTS', '<1000000', 'SD/MI', NULL, 75, 89, 80, 100, 80, 100, 100, 89.14, 10.15, NULL, '2026-05-01 15:34:11', 'smp maarif', 'DKV', 75.49, 'Ya', 0.9046, 0.8915, 'Sangat Cocok'),
(2, 'ali', 'IX', 'L', 'SMP/MTS', '> 4500000', 'SMP/MTS', NULL, 60, 70, 70, 60, 60, 60, 80, 65.71, 7.28, NULL, '2026-05-01 15:35:46', 'SMP MUHAMADIYAH CILIBUR', 'DKV', 59.46, 'Ya', 0.6947, 0.6726, 'Cukup Cocok');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bobot_kriteria`
--
ALTER TABLE `bobot_kriteria`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `hasil`
--
ALTER TABLE `hasil`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `bobot_kriteria`
--
ALTER TABLE `bobot_kriteria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `hasil`
--
ALTER TABLE `hasil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
