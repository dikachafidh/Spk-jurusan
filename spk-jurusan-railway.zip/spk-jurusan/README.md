# spk-jurusan
